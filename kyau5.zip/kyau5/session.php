<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style1 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 80px;
	color: #FF0000;
	font-weight: bold;
}
-->
</style>
<link rel="stylesheet" href="css/style1.css" type="text/css" media="all">
</head>

<body>
<table width="90%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td colspan="3"><?php 	require_once("header.php")			?>   </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td width="0%">&nbsp;</td>
    <td width="0%"><ul class="nav">
    </ul></td>
  </tr>
  <tr>
    <td colspan="3"><div align="center"></div></td>
  </tr>
  
  <tr>
    <td>&nbsp;</td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><?php	require_once("footer.php")	?></td>
  </tr>
</table>
</body>
</html>
